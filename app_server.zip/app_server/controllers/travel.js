/* GET travel view */
const travel = (reg, res) => {
    res.render('travel', {title: 'Travlr Getaways'});
};

module.exports = {
    travel
};