const mongoose = require('mongoose');

// Define the room schema
const roomsSchema = new mongoose.Schema({
    code: { type: String, required: true, index: true },
    name: { type: String, required: true, index: true },
    description: { type: String, required: true },
    rate: { type: String, required: true },
    link: { type: String},
    image: { type: String, required: true }
});

mongoose.model('rooms', roomsSchema);