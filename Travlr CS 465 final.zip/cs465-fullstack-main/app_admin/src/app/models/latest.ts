export interface Latest {
    _id: string, // internal MongoDB primary key 
    code: string,
    title: string,
    link: string
}
