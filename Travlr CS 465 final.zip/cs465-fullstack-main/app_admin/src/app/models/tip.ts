export interface Tip {
    _id: string, // internal MongoDB primary key 
    code: string,
    title: string
}
