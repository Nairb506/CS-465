export default [
    {
        "code": "LP001",
        "title": "2023 Best Beaches Contest Winners"
    },
    {
        "code": "LP002",
        "title": "Top 10 Diving Spots"
    },
    {
        "code": "LP003",
        "title": "Fishing ban to be implemented this year"
    },
    {
        "code": "LP004",
        "title": "Lifeguard saves child from drowning"
    }
]