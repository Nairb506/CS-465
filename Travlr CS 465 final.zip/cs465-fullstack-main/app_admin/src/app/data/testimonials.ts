export default [
    {
        "code": "TES001",
        "description": "\"In hac habitasse platea dictumst. Integer purus justo, egestas eu consectetur eu, cursus in tortor. Quisque nec nunc ac mi ultrices iaculis. Aenean quis elit mauris, nec vestibulum lorem.\"",
        "person": "Juan De La Cruz"
    }
]