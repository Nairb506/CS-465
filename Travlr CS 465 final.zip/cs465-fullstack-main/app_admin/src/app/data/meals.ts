export default [
    {
        "code": "MP001",
        "mealName": "Fried Salmon Special",
        "mealType": "SEAFOOD SPECIAL",
        "image": "seafoods.jpg",
        "description": "I'm a product overview. Here you can write more information about your product. Buyers like to know ..."
    },
    {
        "code": "MP002",
        "mealName": "Choco Ice Cream Sandwich",
        "mealType": "SUMPTUOUS DESSERTS",
        "image": "desserts.jpg",
        "description": "I'm a product overview. Here you can write more information about your product. Buyers like to know ..."
    },
    {
        "code": "MP003",
        "mealName": "Mixed Buffet",
        "mealType": "BUFFET",
        "image": "buffet.jpg",
        "description": "I'm a product overview. Here you can write more information about your product. Buyers like to know ..."
    }
]