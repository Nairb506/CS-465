export default [
    {
        "code": "BP001",
        "title": "2023 Best Beaches Contest Winners",
        "date": "April 02, 2023",
        "description": "Integer magna leo, posuere et dignissim vitae, porttitor at odio. Pellentesque a metus nec magna placerat volutpat. Nunc nisi mi, elementum sit amet..."
    },
    {
        "code": "BP002",
        "title": "Top 10 Diving Spots",
        "date": "May 29, 2023",
        "description": "Maecenas scelerisque odio quis arcu fringilla malesuada. Nulla facilisi. In libero nulla, fermentum ut pretium ac, pharetra et eros..."
    }
]