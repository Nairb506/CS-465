export default [
        {
            "code": "TIP001",
            "title": "What to bring on the beach?"
        },
        {
            "code": "TIP002",
            "title": "Planning Fun Activities"
        },
        {
            "code": "TIP003",
            "title": "Diving Checklist"
        },
        {
            "code": "TIP004",
            "title": "First Aid"
        },
        {
            "code": "TIP005",
            "title": "How to Build a Sand Castle?"
        },
        {
            "code": "TIP006",
            "title": "Tanning Tips"
        }
]